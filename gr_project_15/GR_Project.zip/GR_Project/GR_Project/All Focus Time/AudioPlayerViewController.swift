//
//  AllFocusTimes.swift
//  GR_Project
//
//  Created by Хамза Кабылбек on 05.11.2023.
//



import UIKit
import AVFoundation

class AudioPlayerViewController: UIViewController {

    lazy var playPauseButton: UIButton = {
        let button = UIButton()
        let playImage = UIImage(systemName: "play.fill")?.withConfiguration(UIImage.SymbolConfiguration(pointSize: 30))
        button.setImage(playImage, for: .normal)
        button.tintColor = .black
        button.addTarget(self, action: #selector(playPauseAction), for: .touchUpInside)
        return button
    }()

    lazy var previousButton: UIButton = {
        let button = UIButton()
        let previousImage = UIImage(systemName: "backward.fill")?.withConfiguration(UIImage.SymbolConfiguration(pointSize: 30))
        button.setImage(previousImage, for: .normal)
        button.tintColor = .black
        button.addTarget(self, action: #selector(previousAction), for: .touchUpInside)
        return button
    }()

    lazy var nextButton: UIButton = {
        let button = UIButton()
        let nextImage = UIImage(systemName: "forward.fill")?.withConfiguration(UIImage.SymbolConfiguration(pointSize: 30))
        button.setImage(nextImage, for: .normal)
        button.tintColor = .black
        button.addTarget(self, action: #selector(nextAction), for: .touchUpInside)
        return button
    }()


    var audioPlayer: AVAudioPlayer?
    var currentAudioIndex = 0

    let musicIconImageView: UIImageView = {
        let imageView = UIImageView(image: UIImage(named: "lofi-girl")) // Изображение по умолчанию
        imageView.layer.cornerRadius = 60
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        return imageView
        
    }()

    var buttonImageConfiguration: ((String, CGFloat) -> UIImage?) = { symbolName, pointSize in
        let configuration = UIImage.SymbolConfiguration(pointSize: pointSize)
        return UIImage(systemName: symbolName)?.withConfiguration(configuration)
    }

    var audioFileNames = [
        "once-in-paris-168895",
        "zvuki-prirody-1_-kapli-dozhdya",
        "good-night-160166"
    ]

    var imageNames = [
        "lofi-girl",
        "zvuki_dozhd",
        "lofi-boy"
    ]

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .systemBlue
        
        let appearance = UINavigationBarAppearance()
        appearance.largeTitleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.black]
        self.navigationItem.standardAppearance = appearance
        navigationItem.title = "Relax Music"
        navigationController?.navigationBar.prefersLargeTitles = true

        // Add buttons and image view to the view
        for viewToAdd in [previousButton, playPauseButton, nextButton, musicIconImageView] {
            viewToAdd.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(viewToAdd)
        }

        setupConstraints()
        setupInitialAudio()
    }

    func setupConstraints() {
        // Set constraints for buttons and image view
        NSLayoutConstraint.activate([

            
            musicIconImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            musicIconImageView.topAnchor.constraint(equalTo: view.topAnchor, constant: 190),
            musicIconImageView.widthAnchor.constraint(equalToConstant: 300),
            musicIconImageView.heightAnchor.constraint(equalToConstant: 300),

            previousButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 50),
            previousButton.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 120),
            previousButton.widthAnchor.constraint(equalToConstant: 90),
            previousButton.heightAnchor.constraint(equalToConstant: 90),

            playPauseButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            playPauseButton.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 120),
            playPauseButton.widthAnchor.constraint(equalToConstant: 90),
            playPauseButton.heightAnchor.constraint(equalToConstant: 90),

            nextButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -50),
            nextButton.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 120),
            nextButton.widthAnchor.constraint(equalToConstant: 90),
            nextButton.heightAnchor.constraint(equalToConstant: 90)
        ])
    }

    func setupInitialAudio() {
        if let path = Bundle.main.path(forResource: audioFileNames[currentAudioIndex], ofType: "mp3") {
            let url = URL(fileURLWithPath: path)
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: url)
                audioPlayer?.prepareToPlay()
            } catch {
                print("Error: Couldn't load audio file")
            }
        }
    }

    @objc func playPauseAction(sender: UIButton) {
        animateButtonPress(for: sender)

        if let player = audioPlayer {
            if player.isPlaying {
                player.pause()
                let playImage = buttonImageConfiguration("play.fill", 30)
                playPauseButton.setImage(playImage, for: .normal)
                
                // Анимация возврата к исходному размеру
                UIView.animate(withDuration: 0.2, animations: {
                    self.musicIconImageView.transform = CGAffineTransform.identity
                })
            } else {
                player.play()
                let pauseImage = buttonImageConfiguration("pause.fill", 30)
                playPauseButton.setImage(pauseImage, for: .normal)
                
                // Анимация изменения размера при нажатии на "Play"
                UIView.animate(withDuration: 0.2, animations: {
                    self.musicIconImageView.transform = CGAffineTransform(scaleX: 1.2, y: 1.2)
                })
            }
        } else {
            playCurrentAudio()
        }
    }


    @objc func previousAction(sender: UIButton) {
        animateButtonPress(for: sender)
        currentAudioIndex = (currentAudioIndex - 1 + audioFileNames.count) % audioFileNames.count
        updateAudio()
    }

    @objc func nextAction(sender: UIButton) {
        animateButtonPress(for: sender)
        currentAudioIndex = (currentAudioIndex + 1) % audioFileNames.count
        updateAudio()
    }

    func updateAudio() {
        if let player = audioPlayer {
            player.stop()
            player.currentTime = 0
        }
        playCurrentAudio()
    }

    func playCurrentAudio() {
        let audioFileName = audioFileNames[currentAudioIndex]
        let imageName = imageNames[currentAudioIndex]

        if let path = Bundle.main.path(forResource: audioFileName, ofType: "mp3") {
            let url = URL(fileURLWithPath: path)
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: url)
                audioPlayer?.prepareToPlay()
                audioPlayer?.play()
                musicIconImageView.image = UIImage(named: imageName)
                let pauseImage = buttonImageConfiguration("pause.fill", 30)
                playPauseButton.setImage(pauseImage, for: .normal)
            } catch {
                print("Error: Couldn't load audio file")
            }
        }
    }

    func animateButtonPress(for button: UIButton) {
        UIView.animate(withDuration: 0.1, animations: {
            button.transform = CGAffineTransform(scaleX: 1.2, y: 1.2)
        }, completion: { _ in
            UIView.animate(withDuration: 0.1) {
                button.transform = CGAffineTransform.identity
            }
        })
    }
}
