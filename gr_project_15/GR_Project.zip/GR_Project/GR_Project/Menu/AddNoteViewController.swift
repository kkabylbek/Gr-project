//
//  AddNoteViewController.swift
//  GR_Project
//
//  Created by Хамза Кабылбек on 06.11.2023.
//


import UIKit

protocol AddNoteDelegate: AnyObject {
    func didAddNote(note: Note)
    func didCompleteNoteAtIndex(_ index: Int)
}

class AddNoteViewController: UIViewController {
    weak var delegate: AddNoteDelegate?

    private let titleTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Title"
        textField.borderStyle = .roundedRect
        textField.translatesAutoresizingMaskIntoConstraints = false
        return textField
    }()

    private let contentTextView: UITextView = {
        let textView = UITextView()
        textView.text = ""
        textView.layer.borderWidth = 1
        textView.layer.cornerRadius = 8
        textView.layer.borderColor = UIColor.systemGray2.cgColor
        textView.translatesAutoresizingMaskIntoConstraints = false
        return textView
    }()

    lazy var saveButton: UIButton = {
        let button = UIButton()
        button.setTitle("Save", for: .normal)
        button.tintColor = .white
        button.addTarget(self, action: #selector(saveNote), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.backgroundColor = .systemBlue
        button.layer.cornerRadius = 8
        return button
    }()


    private var isCheckboxSelected = false

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Add Note"
        view.backgroundColor = .systemGray5


        view.addSubview(titleTextField)
        view.addSubview(contentTextView)
        view.addSubview(saveButton)
        //view.addSubview(checkboxButton)

        NSLayoutConstraint.activate([
            titleTextField.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            titleTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            titleTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            titleTextField.heightAnchor.constraint(equalToConstant: 40),

            contentTextView.topAnchor.constraint(equalTo: titleTextField.bottomAnchor, constant: 16),
            contentTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            contentTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            contentTextView.heightAnchor.constraint(equalToConstant: 150),

            saveButton.topAnchor.constraint(equalTo: contentTextView.bottomAnchor, constant: 16),
            saveButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            saveButton.heightAnchor.constraint(equalToConstant: 40),
            saveButton.widthAnchor.constraint(equalToConstant: 100),


        ])
    }

    @objc private func saveNote() {
        guard let title = titleTextField.text, let content = contentTextView.text, !title.isEmpty, !content.isEmpty else {
            return
        }

        let newNote = Note(title: title, content: content, isCompleted: isCheckboxSelected)
        delegate?.didAddNote(note: newNote)
        dismiss(animated: true, completion: nil)
    }
    
}
