//
//  NoteTableViewCell.swift
//  GR_Project
//
//  Created by Хамза Кабылбек on 06.11.2023.
//

import UIKit

protocol NoteCellDelegate: AnyObject {
    func didToggleCheckbox(atIndex index: Int)
}

class NoteTableViewCell: UITableViewCell {
    let titleLabel = UILabel()
    let contentLabel = UILabel()
    let checkboxImageView = UIImageView()

    weak var delegate: NoteCellDelegate?

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)

        titleLabel.font = UIFont.boldSystemFont(ofSize: 16)
        contentLabel.font = UIFont.systemFont(ofSize: 14)

        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        contentLabel.translatesAutoresizingMaskIntoConstraints = false
        checkboxImageView.translatesAutoresizingMaskIntoConstraints = false

        contentView.addSubview(titleLabel)
        contentView.addSubview(contentLabel)
        contentView.addSubview(checkboxImageView)

        let checkboxSize: CGFloat = 30
        
        checkboxImageView.layer.cornerRadius = checkboxSize / 2 // Установка радиуса скругления в половину размера изображения
         checkboxImageView.clipsToBounds = true // Обрезать изображение для соответствия радиусу скругления


        NSLayoutConstraint.activate([

         titleLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 12), // Увеличьте значение константы
         titleLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
         titleLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),

         contentLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 8), // Увеличьте значение константы
         contentLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
         contentLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),


         checkboxImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
         checkboxImageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
         checkboxImageView.widthAnchor.constraint(equalToConstant: checkboxSize),
         checkboxImageView.heightAnchor.constraint(equalToConstant: checkboxSize),
        ])

        checkboxImageView.image = UIImage(systemName: "square") // Используем системную иконку квадрата
        checkboxImageView.tintColor = .black // Черный цвет квадрата

        // Добавим жест нажатия на изображение квадрата
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(checkboxTapped))
        checkboxImageView.addGestureRecognizer(tapGesture)
        checkboxImageView.isUserInteractionEnabled = true
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    @objc func checkboxTapped() {
        delegate?.didToggleCheckbox(atIndex: tag)
    }

    func configure(with note: Note, index: Int) {
        titleLabel.text = note.title
        contentLabel.text = note.content
        let imageName = note.isCompleted ? "checked_checkbox" : "unchecked_checkbox"
        let image = UIImage(named: imageName)
        checkboxImageView.image = image
        tag = index
    }
}
