//
//  TabBarController.swift
//  GR_Project
//
//  Created by Хамза Кабылбек on 05.11.2023.
//


import UIKit

class TabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        generateTabBar()
        setTabBarAppearance()
        setUpTabs()
    }
    
    
        func setUpTabs(){
            let MenuVc = MenuViewController()
            let TimerVC = TimerViewController()
            let AllfocusTimesVc = AudioPlayerViewController()
    
    
            MenuVc.navigationItem.largeTitleDisplayMode = .always
            TimerVC.navigationItem.largeTitleDisplayMode = .always
            AllfocusTimesVc.navigationItem.largeTitleDisplayMode = .always
    
            let nav1 = UINavigationController(rootViewController: MenuVc)
            let nav2 = UINavigationController(rootViewController: TimerVC)
            let nav3 = UINavigationController(rootViewController: AllfocusTimesVc)
    
            nav1.tabBarItem = UITabBarItem(title: "Menu", image: UIImage(systemName: "note.text"), tag: 1)
            nav2.tabBarItem = UITabBarItem(title: "Timer", image: UIImage(systemName: "timer"), tag: 3)
            nav3.tabBarItem = UITabBarItem(title: "Player", image: UIImage(systemName: "play.fill"), tag: 4)
    
            for nav in [nav1,nav2,nav3]{
                nav.navigationBar.prefersLargeTitles = true
            }
    
    
            setViewControllers(
                                [nav1,nav2,nav3]
                               , animated: true)
        }
    
    
    private func generateTabBar() {
        viewControllers = [
            generateVC(
                viewController: MenuViewController(),
                title: "Menu",
                image: UIImage(systemName: "note.text")
            ),
            generateVC(
                viewController: TimerViewController(),
                title: "Timer",
                image: UIImage(systemName: "timer")
            ),
            generateVC(
                viewController: AudioPlayerViewController(),
                title: "Player",
                image: UIImage(systemName: "play.fill")
            )
        ]
    }
    
    private func generateVC(viewController: UIViewController, title: String, image: UIImage?) -> UIViewController {
        viewController.tabBarItem.title = title
        viewController.tabBarItem.image = image
        return viewController
    }
    
    
    
    private func setTabBarAppearance() {
        let positionOnX: CGFloat = 10
        let positionOnY: CGFloat = 14
        let width = tabBar.bounds.width - positionOnX * 2
        let height = tabBar.bounds.height + positionOnY * 2
        
        let roundLayer = CAShapeLayer()
        
        let bezierPath = UIBezierPath(
            roundedRect: CGRect(
                x: positionOnX,
                y: tabBar.bounds.minY - positionOnY,
                width: width,
                height: height
            ),
            cornerRadius: height / 2
        )
        
        roundLayer.path = bezierPath.cgPath
        
        tabBar.layer.insertSublayer(roundLayer, at: 0)
        
        tabBar.itemWidth = width / 5
        tabBar.itemPositioning = .centered
        
        roundLayer.fillColor = UIColor.mainWhite.cgColor
        
        tabBar.tintColor = .tabBarItemAccent
        tabBar.unselectedItemTintColor = .tabBarItemLight
    }
    
    
}

